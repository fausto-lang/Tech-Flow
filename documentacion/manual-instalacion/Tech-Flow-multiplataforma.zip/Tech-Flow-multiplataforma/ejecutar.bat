@echo off
setlocal
cd /d "%~dp0"
java -Dtechflow.data.dir="data" -jar "Tech-Flow.jar" %*
