#!/bin/bash
set -e
cd "$(dirname "$0")"
java -Dtechflow.data.dir="data" -jar "Tech-Flow.jar" "$@"
